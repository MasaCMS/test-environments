<cfoutput>
	<p id="e2e-plugin-output">#esapiEncode('html', pluginConfig.getSetting('greeting'))#</p>
</cfoutput>
<cfoutput>
	<p id="e2e-plugin-version">Plugin version 2.0</p>
</cfoutput>
